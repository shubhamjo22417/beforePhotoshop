$(document).ready(function () {

    function graphData(data) {

        var chart = new CanvasJS.Chart("chartContainer", {
            title: {
                text: "Forecast Graph"
            },
            axisY: {
                suffix: " °C",
                maximum: 40,
                gridThickness: 0
            },
            toolTip: {
                shared: true,
                content: "{name} </br> <strong>Temperature: </strong> </br> Min: {y[0]} °C, Max: {y[1]} °C"
            },
            data: [{
                type: "rangeSplineArea",
                fillOpacity: 0.1,
                color: "#91AAB1",
                indexLabelFormatter: formatter,
                dataPoints: [
                    { label: data[0][0], y: [data[0][2], data[0][1]], name: "rainy" },
                    { label: data[1][0], y: [data[1][2], data[1][1]], name: "rainy" },
                    { label: data[2][0], y: [data[2][2], data[2][1]], name: "sunny" },

                ]
            }]
        });
        chart.render();

        var images = [];

        addImages(chart);

        function addImages(chart) {
            for (var i = 0; i < chart.data[0].dataPoints.length; i++) {
                var dpsName = chart.data[0].dataPoints[i].name;
                if (dpsName == "cloudy") {
                    images.push($("<img>").attr("src", "https://canvasjs.com/wp-content/uploads/images/gallery/gallery-overview/cloudy.png"));
                } else if (dpsName == "rainy") {
                    images.push($("<img>").attr("src", "https://canvasjs.com/wp-content/uploads/images/gallery/gallery-overview/rainy.png"));
                } else if (dpsName == "sunny") {
                    images.push($("<img>").attr("src", "https://canvasjs.com/wp-content/uploads/images/gallery/gallery-overview/sunny.png"));
                }

                images[i].attr("class", dpsName).appendTo($("#chartContainer>.canvasjs-chart-container"));
                positionImage(images[i], i);
            }
        }

        function positionImage(image, index) {
            var imageCenter = chart.axisX[0].convertValueToPixel(chart.data[0].dataPoints[index].x);
            var imageTop = chart.axisY[0].convertValueToPixel(chart.axisY[0].maximum);

            image.width("40px")
                .css({
                    "left": imageCenter - 20 + "px",
                    "position": "absolute", "top": imageTop + "px",
                    "position": "absolute"
                });
        }

        $(window).resize(function () {
            var cloudyCounter = 0, rainyCounter = 0, sunnyCounter = 0;
            var imageCenter = 0;
            for (var i = 0; i < chart.data[0].dataPoints.length; i++) {
                imageCenter = chart.axisX[0].convertValueToPixel(chart.data[0].dataPoints[i].x) - 20;
                if (chart.data[0].dataPoints[i].name == "cloudy") {
                    $(".cloudy").eq(cloudyCounter++).css({ "left": imageCenter });
                } else if (chart.data[0].dataPoints[i].name == "rainy") {
                    $(".rainy").eq(rainyCounter++).css({ "left": imageCenter });
                } else if (chart.data[0].dataPoints[i].name == "sunny") {
                    $(".sunny").eq(sunnyCounter++).css({ "left": imageCenter });
                }
            }
        });

        function formatter(e) {
            if (e.index === 0 && e.dataPoint.x === 0) {
                return " Min " + e.dataPoint.y[e.index] + "°";
            } else if (e.index == 1 && e.dataPoint.x === 0) {
                return " Max " + e.dataPoint.y[e.index] + "°";
            } else {
                return e.dataPoint.y[e.index] + "°";
            }
        }

    }


    
    let w_temp_c;
   // let w_temp_f;
    // let w_location;
    let w_img;
    let w_feellikes_c;
    //let w_feellikes_f;
    let w_humidity;
    let w_wind_kph;
  //  let w_wind_mph;
    let w_city;
    let w_state;
    let w_country;
    let w_condition;
    let w_pressure_in;
    let w_min_temp;
    let w_max_temp;
    
    let forecastData;
    var temp = []
    let tem2 = [];

    $('#mysearchbutton').click(function () {
        // let getdata =  $("document.getElementById('lattitude1').value").val();
        let searchkey = $("#mysearch").val().toLowerCase();
       // console.log(getdata);
        $.ajax({
            type: 'GET',
            dataType: 'json',
            url:  "http://api.weatherapi.com/v1/forecast.json?key=73a35b67d0d84661921182344201810&q=" + searchkey + "&days=3",
            success: function (res) {
                console.log('successfully get data from json-server')
                let weather = []
                

                tem2 = res.forecast.forecastday.map((d) => {
                    return [d.date, d.day.maxtemp_c, d.day.mintemp_c, d.day.avgtemp_c, d.day.condition.text, d.day.condition.icon]
                })
                forecastData = temp.concat(tem2)
               

                graphData(forecastData);


                w_temp_c = res.current.temp_c;
                w_temp_f = res.current.temp_f;
                //  w_location = ;
                w_img = res.current.condition.icon;


                w_condition = res.current.condition.text;
                console.log(w_condition)
                w_feellikes_c = res.current.feelslike_c;
                w_feellikes_f = res.current.feelslike_f;
                w_humidity = res.current.humidity;
                w_wind_kph = res.current.wind_kph;
                w_wind_mph = res.current.wind_mph;

                w_pressure_in = res.current.pressure_in

                w_min_temp = res.forecast.forecastday[0].day.mintemp_c;
                w_max_temp = res.forecast.forecastday[0].day.maxtemp_c;
                // res.forecast.forecastday[0].day.avgtemp_c;
                w_city = res.location.name;
                w_state = res.location.region;
                w_country = res.location.country;




                var x = false
                $.each(res, function () {
                    if (!x) {

                        weather +=
                            `  <div class="row no-gutters m-3 mt-5 mb-4 main1_container">
                            <div class="col-md-4 py-auto ">
                                <div class="primary_data main_data ">
                                    <div class="col-12 w_city mb-2">${w_city}, <span id="w_state">&nbsp; ${w_state} - ${w_country}</span> </div>
                                    <div class="col-12 w_date">  <span>  &nbsp; ${forecastData[0][0]} </span> </div>
                                    <div class="col-12  w_temp mt-3">${w_temp_c} °C</div>
                                    <div class="row col-12">
                                        <div class="col-6 w_img">
                                            <img src="${w_img}" alt="" srcset="">
                                        </div>
                                        <div class="col-6 w_condition my-auto mx-auto">
                                            ${w_condition}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8 my-auto ">
                                <div class="primary_data secondry_data mr-2  my-auto">
                
                                    <table class="table my-3">
                                        <tbody>
                                            <tr>
                                                <th scope="row">Min. Temperature</th>
                                                <td>${w_min_temp} °C</td>
                                              </tr>
                                              <tr>
                                                <th scope="row">Max. Temperature</th>
                                                <td>${w_max_temp} °C</td>
                                              </tr>
                                          <tr>
                                            <th scope="row">Pressure</th>
                                            <td>${w_pressure_in}</td>
                                          </tr>
                                          <tr>
                                            <th scope="row">Humidity</th>
                                            <td>${w_humidity}</td>
                                          </tr>
                                          <tr>
                                            <th scope="row">Wind Speed</th>
                                            <td>${w_wind_kph}</td>
                                          </tr>
                                          <tr>
                                            <th scope="row">Feels Like</th>
                                            <td>${w_feellikes_c}</td>
                                          </tr>
                                        </tbody>
                                      </table>
                                </div>
                            </div>
                        </div>
    
                        <div class="container-fluid ">
                        <h2 class="text-center">3 Days ForeCast Data</h2>
                    <div class="row no-gutters mx-3 mt-5">
                <div class="col-12 col-sm-6 col-md-4 ">
                    <div class="primary_data forecast_data my-3  ">
                        <div class="col-12 f_date pt-2 mb-2">
                            ${forecastData[0][0]}
                        </div>
    
                        <div class="col-12 f_temp">
                        ${forecastData[0][3]} °C
                        </div>
                        <div class="row col-12 f_img m-auto">
                            <div class="col-6 "><img src="${forecastData[0][5]}" alt="" srcset="">
                            </div>
                            <div class="col-6 my-auto"> <span>${forecastData[0][4]}</span> </div>
                        </div></br>
                           <div class="row col-12 f_img m-auto">
                            <div class="col-6 ">
                              <span style="color: rgb(90, 90, 90);"> Min: ${forecastData[0][2]} °C</span>
                            </div>
                            <div class="col-6 my-auto"> 
                            <span style="color: rgb(90, 90, 90);"> Max: ${forecastData[0][1]} °C</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 ">
                    <div class="primary_data forecast_data m-3  ">
                        <div class="col-12 f_date pt-2 mb-2">
                        ${forecastData[1][0]} 
                        </div>
    
                        <div class="col-12 f_temp">
                        ${forecastData[1][3]} °C
                        </div>
                        <div class="row col-12 f_img m-auto">
                            <div class="col-6 "><img src="${forecastData[1][5]}" alt="" srcset="">
                            </div>
                            <div class="col-6 my-auto"> <span>${forecastData[1][4]}</span> </div>
                        </div></br>
                        <div class="row col-12 f_img m-auto">
                        <div class="col-6 ">
                          <span style="color: rgb(90, 90, 90);"> Min: ${forecastData[0][2]} °C</span>
                        </div>
                        <div class="col-6 my-auto"> 
                        <span style="color: rgb(90, 90, 90);"> Max: ${forecastData[0][1]} °C</span>
                        </div>
                    </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 ">
                    <div class="primary_data forecast_data my-3  ">
                        <div class="col-12 f_date pt-2 mb-2">
                        ${forecastData[2][0]}
                        </div>
    
                        <div class="col-12 f_temp">
                        ${forecastData[2][3]} °C
                        </div>
                        <div class="row col-12 f_img m-auto">
                            <div class="col-6 "><img src="${forecastData[2][5]}" alt="" srcset="">
                            </div>
                            <div class="col-6 my-auto"> <span>${forecastData[2][4]}</span> </div>
                        </div></br>
                        <div class="row col-12 f_img m-auto">
                        <div class="col-6 ">
                          <span style="color: rgb(90, 90, 90);"> Min: ${forecastData[0][2]} °C</span>
                        </div>
                        <div class="col-6 my-auto"> 
                        <span style="color: rgb(90, 90, 90);"> Max: ${forecastData[0][1]} °C</span>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>     
        <h2 class="text-center">ForeCast Graph</h2>   
   `}
                    x = true
                })
                $('.main_container').empty()
                $('.main_container').append(weather)

            }
        })
    })

})
